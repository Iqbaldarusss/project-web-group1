<?php
// removeitem.php

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["cart_id"])) {
    $cart_id = $_POST["cart_id"];

    // Add your database connection code here
    $dbname = "database_project_web";
    $servername = "localhost";
    $user = "root";
    $password = "";

    $conn = new mysqli($servername, $user, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare and execute the SQL delete command
    $stmt = $conn->prepare("DELETE FROM cart WHERE cart_id = ?");
    $stmt->bind_param("i", $cart_id);
    $stmt->execute();

    // Close the prepared statement and database connection
    $stmt->close();
    $conn->close();

    echo "Item removed successfully";
} else {
    echo "Invalid request";
}
?>