<?php
session_start();

if (isset($_POST['stringData'])) {

    $string = $_POST['stringData'];
    $parts = explode(",", $string);
  
    $dbname = "database_project_web";
    $servername = "localhost";
    $user = "root";
    $password = "";

    $conn = new mysqli($servername, $user, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $query = mysqli_query($conn,"SELECT id FROM credentials WHERE username = '" . $_SESSION["username"] ."'");

    $r = mysqli_fetch_object($query);

    $cust_id = $r->id;

    $query = mysqli_query($conn,"SELECT * FROM sportshoes WHERE ItemName = '" . $parts[0] ."'");

    $r = mysqli_fetch_object($query);

    $item_id = $r->Item_ID;

    $item_price = $r->ItemPrice;
    
    $item_name = $r->ItemName;

    $status = "in progress";

    $quantity = 1;

    $sql = "INSERT INTO cart (id, item_id, item_name, quantity, total_price, status_item) VALUES (?,?,?,?,?,?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('ssssss', $cust_id, $item_id, $item_name, $quantity, $item_price, $status);
    $stmt->execute();

    $cust_id = null;
    $item_id = null;
    $quantity = null;
    $item_price = null;
    $status = null;
    $item_name = null;

    echo "success";

}
