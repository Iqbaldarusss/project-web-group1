<?php

session_start();
if (!isset($_SESSION["username"])) {
    header("Location: login.php");
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home Page</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>

    <header>

        <nav class="top-nav">

            <div class="logo-nav">

                <a href="homepage.php">SNEAKER'S SHOP</a>

            </div>

            <h3>NEW SHOES RELEASES</h3>

            <div class="option-nav">

                <a href="homepage.php">Home Page</a>
                |
                <a href="account.php">Account</a>
                |
                <a href="cart.php">Cart</a>
                |
                <a href="aboutus.html">About Us</a>
                |
                <a href="Logout.php">Log out</a>

            </div>
        </nav>

    </header>

    <div class="content">

        <div class="left-content">

            <a href="running.php">Running</a>
            <a href="casual.php">Casual</a>
            <a href="basketball.php">Basketball</a>
            <a href="sport.php">Sport</a>

        </div>

        <div class="center-content">

            <div class="item" onclick="showShoeDetails('MerrelBlack', '9 UK', 'RM149.99')">

                <div class="pic-item">

                    <img src="gambar/casual1.jpeg" alt="">

                </div>

                <div class="pic-desc">

                    <label>Name: MerrelBlack</label>
                    <label>Size: 9 UK</label>
                    <label>Price: RM149.99</label>
                    <button style="margin-top: 15px;">Add to cart</button>

                </div>

            </div>

            <div class="item" onclick="showShoeDetails('DarkCampus', ' 7 UK', 'RM129.99')">

                <div class="pic-item">

                    <img src="gambar/casual2.jpeg" alt="">

                </div>

                <div class="pic-desc">

                    <label>Name: DarkCampus</label>
                    <label>Size: 7 UK</label>
                    <label>Price: RM129.99</label>
                    <button style="margin-top: 15px;">Add to cart</button>

                </div>

            </div>

            <div class="item" onclick="showShoeDetails('Dr.Cardin', '10 UK', 'RM189.99')">

                <div class="pic-item">

                    <img src="gambar/casual3.jpeg" alt="">

                </div>

                <div class="pic-desc">

                    <label>Name: Dr.Cardin</label>
                    <label>Size: 10 UK</label>
                    <label>Price: RM189.99</label>
                    <button style="margin-top: 15px;">Add to cart</button>

                </div>

            </div>

        </div>

        <div class="right-banner" style="margin-top: 50px;">

            <img src="gambar/right-banner.jpeg" alt="">

        </div>

    </div>

    <div id="floatingWindow" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal()">&times;</span>
            <h2 id="shoeName"></h2>
            <h2 id="data"></h2>

            <div class="bttn">

                <button onclick="addToCart()">Yes</button>
                <button onclick="closeModal()">No</button>

            </div>

        </div>
    </div>

    <script>
        function showShoeDetails(name, size, price) {
            const modal = document.getElementById('floatingWindow');
            const shoeName = document.getElementById('shoeName');
            const data = document.getElementById('data');

            data.textContent = name + "," + size + "," + price;
            data.style.display = 'none';

            shoeName.textContent = `Are you sure to add this item?`;

            modal.style.display = 'block';
        }

        // Function to close the modal window
        function closeModal() {
            const modal = document.getElementById('floatingWindow');
            modal.style.display = 'none';
        }

        // Event listener to close the modal when clicking outside the modal window
        window.addEventListener('click', function(event) {
            const modal = document.getElementById('floatingWindow');
            if (event.target === modal) {
                modal.style.display = 'none';
            }
        });

        function addToCart() {

            var stringData = document.getElementById("data").textContent;

            fetch('cart_process.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    },
                    body: 'stringData=' + encodeURIComponent(stringData)
                })
                .then(response => response.text())
                .then(data => {
                    // Handle the response from PHP
                    console.log(data);
                })
                .catch(error => {
                    // Handle errors, if any
                    console.error('Error:', error);
                });

            closeModal();

        }
    </script>

</body>

</html>