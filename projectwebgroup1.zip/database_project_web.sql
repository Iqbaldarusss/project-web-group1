-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 01, 2023 at 08:12 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `database_project_web`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `cart_id` int(11) NOT NULL,
  `id` int(11) DEFAULT NULL,
  `item_id` int(11) DEFAULT NULL,
  `item_name` varchar(100) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `total_price` double DEFAULT NULL,
  `status_item` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`cart_id`, `id`, `item_id`, `item_name`, `quantity`, `total_price`, `status_item`) VALUES
(1, 1, 9, 'UABoost', 1, 179.99, 'in progress'),
(3, 1, 1, 'AJ1', 1, 249.99, 'in progress'),
(4, 2, 7, 'DarkCampus', 1, 129.99, 'in progress');

-- --------------------------------------------------------

--
-- Table structure for table `credentials`
--

CREATE TABLE `credentials` (
  `id` int(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `credentials`
--

INSERT INTO `credentials` (`id`, `username`, `password`, `email`) VALUES
(1, 'ali', '$2y$10$2nYuBtf3DDlEVc6oH4pFdek5dT1nZWyt7ulyaLWjLALChsosztkXy', 'ali@gmail.com'),
(2, 'abu', '$2y$10$tss7Akwu7diCCp/hcIFL9.NfMCFeBec7pjrb7Z3ysWfd70mnHnbFK', 'abu@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `sportshoes`
--

CREATE TABLE `sportshoes` (
  `Item_ID` int(11) NOT NULL,
  `ItemName` varchar(255) DEFAULT NULL,
  `ItemPrice` decimal(10,2) DEFAULT NULL,
  `ItemSize` int(11) DEFAULT NULL,
  `Quantity` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sportshoes`
--

INSERT INTO `sportshoes` (`Item_ID`, `ItemName`, `ItemPrice`, `ItemSize`, `Quantity`) VALUES
(1, 'AJ1', '249.99', 8, NULL),
(2, 'UnderArmour', '199.99', 9, NULL),
(3, 'NikeCandy', '219.99', 6, NULL),
(4, 'NikeBlaze', '249.99', 8, NULL),
(5, 'NikeIndigo', '199.99', 7, NULL),
(6, 'MerrelBlack', '149.99', 9, NULL),
(7, 'DarkCampus', '129.99', 7, NULL),
(8, 'Dr.Cardin', '189.99', 10, NULL),
(9, 'UABoost', '179.99', 9, NULL),
(10, 'AdidasActive', '209.99', 9, NULL),
(11, 'HurricaneWind', '149.99', 7, NULL),
(12, 'AsicsFFBoost', '229.99', 11, NULL),
(13, 'NikeTiempo8', '199.99', 6, NULL),
(14, 'OdidasLadies', '109.99', 5, NULL),
(15, 'PowerLegend14', '119.99', 8, NULL),
(16, 'MikeSachai', '139.99', 10, NULL),
(17, 'FelexxOcean', '169.99', 7, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`cart_id`);

--
-- Indexes for table `credentials`
--
ALTER TABLE `credentials`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sportshoes`
--
ALTER TABLE `sportshoes`
  ADD PRIMARY KEY (`Item_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `cart_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `credentials`
--
ALTER TABLE `credentials`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
