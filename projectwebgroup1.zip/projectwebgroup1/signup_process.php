<?php
$dbname = "database_project_web";
$servername = "localhost";
$user = "root";
$password = "";

$conn = new mysqli($servername, $user, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve form data
$name = $_POST['name'];
$email = $_POST['email'];
$password = $_POST['password'];

if ($stmt = $conn->prepare("SELECT id, password FROM credentials WHERE username = ?")) {

    $stmt->bind_param("s", $_POST["name"]);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows() > 0) {

?>

        Username already exits, please use another username
        <button onclick="gosignup()">go back</button>

        <script>
            function gosignup() {

                window.history.back();

            }
        </script>

<?php

    } else {

        $password = password_hash($_POST["password"], PASSWORD_DEFAULT);
        $stmt = $conn->prepare("INSERT INTO credentials (username, email, password) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $name, $email, $password);

        if ($stmt->execute()) {
            echo "Sign up successful!";
        } else {
            echo "Error: " . $stmt->error;
        }
    }
}

$stmt->close();
$conn->close();
?>