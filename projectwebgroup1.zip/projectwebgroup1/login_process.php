<?php

session_start();


$dbname = "database_project_web";
$servername = "localhost";
$user = "root";
$password = "";

$conn = new mysqli($servername, $user, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (!isset($_POST["username"], $_POST["password"])) {

    exit("Empty field");
}

$username = $_POST['username'];
$password = $_POST['password'];

$verify = mysqli_query($conn, "SELECT * FROM credentials");

while ($data = mysqli_fetch_object($verify)) {

    $permission = password_verify($password, $data->password);

    if ($permission == true) {

        $_SESSION["username"] = $username;
        header("Location: homepage.php");
    }
}
?>

Wrong username or password
<button onclick="gosignup()">go back</button>

<script>
    function gosignup() {

        window.history.back();

    }
</script>

<?php
/*$stmt = $conn->prepare("SELECT * FROM credentials WHERE email = ? AND password = ?");
$stmt->bind_param("ss", $username, $password);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // Login successful
    echo "Login successful!";
} else {
    // Login failed
    echo "Invalid username or password";
}*/

$conn->close();

?>