<?php
session_start();
if (!isset($_SESSION["username"])) {
    header("Location: login.php");
    exit(); // Add an exit statement after the header to stop further execution
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Cart</title>
    <link rel="stylesheet" href="style.css">
    <style>
        table,
        th,
        td,
        tr {
            border: 2px solid black;
            border-collapse: collapse;
            background-color: white;
        }
    </style>
</head>

<body>
    <header>
        <nav class="top-nav">
            <div class="logo-nav">
                <a href="homepage.php">SNEAKER'S SHOP</a>
            </div>
            <h3>NEW SHOES RELEASES</h3>
            <div class="option-nav">
                <a href="homepage.php">Home Page</a> |
                <a href="account.php">Account</a> |
                <a href="cart.php">Cart</a> |
                <a href="aboutus.html">About Us</a> |
                <a href="Logout.php">Log out</a>
            </div>
        </nav>
    </header>

    <main>
        <h2 id="cart-title" style="margin-top: 20px; margin-bottom: 40px;">Your Item In Cart</h2>
        <table style="width:100%;">
            <tr>
                <th>Item name</th>
                <th>Item Price</th>
                <th>Quantity</th>
                <th>Action</th>
            </tr>
            <?php
            $dbname = "database_project_web";
            $servername = "localhost";
            $user = "root";
            $password = "";

            $conn = new mysqli($servername, $user, $password, $dbname);

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            $query = mysqli_query($conn, "SELECT * FROM credentials WHERE username = '" . $_SESSION["username"] . "'");
            $r = mysqli_fetch_object($query);
            $cust_id = $r->id;

            $query = mysqli_query($conn, "SELECT * FROM cart WHERE id = '" . $cust_id . "'");

            while ($r = mysqli_fetch_object($query)) {
            ?>
                <tr>
                    <td><?php echo $r->item_name; ?></td>
                    <td><?php echo $r->total_price; ?></td>
                    <td><?php echo $r->quantity; ?></td>
                    <td style="display: flex; justify-content: space-evenly; border: 1px solid black;">
                        <button style="padding: 0 10px;" onclick="removeItem(<?php echo $r->cart_id; ?>)">remove</button>
                        <button style="padding: 0 10px;">buy</button>
                    </td>
                </tr>
            <?php
            }
            ?>
        </table>
    </main>

    <script>
        function removeItem(cart_id) {
    fetch('removeitem.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: 'cart_id=' + encodeURIComponent(cart_id)
    })
    .then(response => response.text())
    .then(data => {
        // Handle the response from PHP
        console.log(data);
        // Optionally, you can reload the page after removing the item
        location.reload();
    })
    .catch(error => {
        // Handle errors, if any
        console.error('Error:', error);
    });
}
    </script>
</body>

</html>