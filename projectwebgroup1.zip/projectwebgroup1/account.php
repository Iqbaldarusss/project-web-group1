<?php

session_start();
if (!isset($_SESSION["username"])) {
    header("Location: login.php");
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home Page</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>

    <header>

        <nav class="top-nav">

            <div class="logo-nav">

                <a href="homepage.php">SNEAKER'S SHOP</a>

            </div>

            <h3>NEW SHOES RELEASES</h3>

            <div class="option-nav">

                <a href="homepage.php">Home Page</a>
                |
                <a href="account.php">Account</a>
                |
                <a href="cart.php">Cart</a>
                |
                <a href="aboutus.html">About Us</a>
                |
                <a href="Logout.php">Log out</a>

            </div>
        </nav>

    </header>

    <main style="display: flex; justify-content: center; align-items: center;padding-bottom:20px;min-height:100vh;">

        <div id="info" style="background-color:white;padding: 0px 20px 20px 20px;border-radius: 10px;">

            <?php

            $dbname = "database_project_web";
            $servername = "localhost";
            $user = "root";
            $password = "";

            $conn = new mysqli($servername, $user, $password, $dbname);

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            $query = mysqli_query($conn, "SELECT * FROM credentials WHERE username = '" . $_SESSION["username"] . "'");

            $r = mysqli_fetch_object($query);

            ?>

            <h1 id="cart-title" style="margin-top: 20px; margin-bottom: 40px;">Your Account Information</h1>

            <h2>ID: <?php

                    echo $r->id;

                    ?></h2>

            <h2>Username: <?php

                            echo $r->username;

                            ?></h2>

            <h2>Email: <?php

                        echo $r->email;

                        ?></h2>

        </div>



    </main>

</body>

</html>